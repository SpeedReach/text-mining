rm data/collection/*
rm indexes/collection/*
rm runs/*
